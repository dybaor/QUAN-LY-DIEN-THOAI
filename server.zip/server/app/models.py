import datetime
from sqlalchemy import Column, String, Integer, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from .database import Base

class Parent(Base):
    __tablename__ = "parents"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)  # Argon2id
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    children = relationship("Child", back_populates="parent")

class Child(Base):
    __tablename__ = "children"
    id = Column(Integer, primary_key=True, index=True)
    parent_id = Column(Integer, ForeignKey("parents.id"), nullable=False)
    name = Column(String(100), nullable=False)
    age = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    parent = relationship("Parent", back_populates="children")
    devices = relationship("Device", back_populates="child")

class Device(Base):
    __tablename__ = "devices"
    id = Column(String(64), primary_key=True)  # device_id dạng UUID
    child_id = Column(Integer, ForeignKey("children.id"), nullable=False)
    fingerprint = Column(String(255), nullable=False)
    name = Column(String(100), default="Windows PC")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    child = relationship("Child", back_populates="devices")

class EnrollmentCode(Base):
    __tablename__ = "enrollment_codes"
    code = Column(String(8), primary_key=True, index=True)  # Mã 8 ký tự
    child_id = Column(Integer, ForeignKey("children.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)          # Hạn 10 phút
    is_used = Column(Boolean, default=False)

    # Thêm vào cuối file app/models.py:

class Policy(Base):
    __tablename__ = "policies"
    id = Column(Integer, primary_key=True, index=True)
    child_id = Column(Integer, ForeignKey("children.id"), nullable=False)
    version = Column(Integer, default=1)  # Đánh số phiên bản chính sách
    daily_quota_weekday_min = Column(Integer, default=90)  # Phút ngày thường (mặc định 90p)
    daily_quota_weekend_min = Column(Integer, default=120) # Phút cuối tuần (mặc định 120p)
    schedule_matrix = Column(String, default="1"*336)       # Ma trận 7x48 = 336 ký tự (1: cho phép, 0: khóa)
    blocked_apps = Column(String, default="")              # Danh sách SHA-256 / tên app cấm
    blocked_domains = Column(String, default="")           # Danh sách domain cấm
    updated_at = Column(DateTime, default=datetime.datetime.utcnow)

class DeviceEvent(Base):
    __tablename__ = "device_events"
    id = Column(Integer, primary_key=True, index=True)
    
    # 7 trường dữ liệu bắt buộc theo đề cương:
    ts = Column(DateTime, nullable=False, default=datetime.datetime.utcnow)
    device_id = Column(String(64), ForeignKey("devices.id"), nullable=False)
    child_id = Column(Integer, ForeignKey("children.id"), nullable=False)
    type = Column(String(50), nullable=False) # app_start, app_stop, locked, blocked_domain, ...
    subject = Column(String(255), nullable=False) # Tên app hoặc Domain cấp 2 (không lưu URL đầy đủ)
    duration_sec = Column(Integer, default=0)
    policy_id = Column(Integer, nullable=True)