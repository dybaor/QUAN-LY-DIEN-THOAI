from typing import Dict
from fastapi import WebSocket

class ConnectionManager:
    def __init__(self):
        # Lưu trữ các kết nối đang active: {device_id: WebSocket}
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, device_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[device_id] = websocket
        print(f"[WS] Thiết bị kết nối: {device_id}")

    def disconnect(self, device_id: str):
        if device_id in self.active_connections:
            del self.active_connections[device_id]
            print(f"[WS] Thiết bị ngắt kết nối: {device_id}")

    async def send_command(self, device_id: str, command: dict) -> bool:
        """Gửi lệnh khẩn cấp xuống Agent (lock_now, extend_time, unlock)"""
        websocket = self.active_connections.get(device_id)
        if websocket:
            await websocket.send_json(command)
            return True
        return False

manager = ConnectionManager()