from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException
from pydantic import BaseModel
from ..websocket_manager import manager

router = APIRouter(tags=["Commands & WebSocket"])

class CommandRequest(BaseModel):
    device_id: str
    action: str  # "lock_now", "unlock", "extend_15m"
    reason: str = "Lệnh từ phụ huynh"

# 1. Endpoint WebSocket để Agent máy con kết nối vào
@router.websocket("/ws/{device_id}")
async def websocket_endpoint(websocket: WebSocket, device_id: str):
    await manager.connect(device_id, websocket)
    try:
        while True:
            # Lắng nghe phản hồi hoặc heartbeat từ agent
            data = await websocket.receive_text()
            print(f"[WS Received from {device_id}]: {data}")
    except WebSocketDisconnect:
        manager.disconnect(device_id)

# 2. Endpoint REST API để Web Dashboard phụ huynh bấm nút gửi lệnh
@router.post("/commands/send")
async def send_emergency_command(req: CommandRequest):
    payload = {
        "action": req.action,
        "reason": req.reason
    }
    is_sent = await manager.send_command(req.device_id, payload)
    if not is_sent:
        raise HTTPException(status_code=404, detail="Thiết bị hiện đang ngoại tuyến (Offline)")
    
    return {"status": "success", "message": f"Đã gửi lệnh {req.action} tới thiết bị thành công"}