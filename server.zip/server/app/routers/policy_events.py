from datetime import date, datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import DeviceEvent, Policy

router = APIRouter(tags=["Policies & Events"])


# ==========================================
# PYDANTIC SCHEMAS
# ==========================================
class PolicyUpdateSchema(BaseModel):
    child_id: int
    daily_quota_weekday_min: int
    daily_quota_weekend_min: int
    schedule_matrix: Optional[str] = "1" * 336
    blocked_apps: Optional[str] = ""
    blocked_domains: Optional[str] = ""


class EventCreateSchema(BaseModel):
    ts: datetime
    device_id: str
    child_id: int
    type: str
    subject: str
    duration_sec: int
    policy_id: Optional[int] = None


# ==========================================
# 1. API QUẢN LÝ CHÍNH SÁCH (POLICY)
# ==========================================
@router.get("/policy/{child_id}")
def get_child_policy(child_id: int, db: Session = Depends(get_db)):
    """Lấy chính sách hiện tại của trẻ, tạo mặc định nếu chưa tồn tại."""
    policy = db.query(Policy).filter(Policy.child_id == child_id).first()
    if not policy:
        policy = Policy(child_id=child_id)
        db.add(policy)
        db.commit()
        db.refresh(policy)
    return policy


@router.put("/policy/update")
def update_policy(req: PolicyUpdateSchema, db: Session = Depends(get_db)):
    """Cập nhật chính sách và tăng version để Agent nhận biết thay đổi."""
    policy = db.query(Policy).filter(Policy.child_id == req.child_id).first()
    if not policy:
        policy = Policy(child_id=req.child_id)
        db.add(policy)

    policy.daily_quota_weekday_min = req.daily_quota_weekday_min
    policy.daily_quota_weekend_min = req.daily_quota_weekend_min
    policy.schedule_matrix = req.schedule_matrix
    policy.blocked_apps = req.blocked_apps
    policy.blocked_domains = req.blocked_domains
    policy.version += 1
    policy.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(policy)
    return {"status": "success", "policy_version": policy.version}


# ==========================================
# 2. API TIẾP NHẬN SỰ KIỆN (EVENTS - 7 TRƯỜNG)
# ==========================================
@router.post("/events/batch")
def receive_events_batch(events: List[EventCreateSchema], db: Session = Depends(get_db)):
    """Tiếp nhận sự kiện theo lô từ máy con Agent (kể cả khi vừa kết nối mạng lại)."""
    new_events = [
        DeviceEvent(
            ts=ev.ts,
            device_id=ev.device_id,
            child_id=ev.child_id,
            type=ev.type,
            subject=ev.subject,
            duration_sec=ev.duration_sec,
            policy_id=ev.policy_id,
        )
        for ev in events
    ]
    db.add_all(new_events)
    db.commit()
    return {"status": "success", "recorded_count": len(new_events)}


@router.get("/events/summary/{child_id}")
def get_usage_summary(child_id: int, db: Session = Depends(get_db)):
    """Tổng hợp sơ bộ thời gian sử dụng phục vụ kiểm toán."""
    events = db.query(DeviceEvent).filter(DeviceEvent.child_id == child_id).all()
    total_seconds = sum(e.duration_sec for e in events)
    return {
        "child_id": child_id,
        "total_usage_minutes": round(total_seconds / 60, 1),
        "total_events_logged": len(events),
    }


# ==========================================
# 3. QUẢN TRỊ DỮ LIỆU & QUYỀN RIÊNG TƯ (NĐ 13/2023)
# ==========================================
@router.delete("/events/cleanup-old-records")
def cleanup_old_events(db: Session = Depends(get_db)):
    """Xóa tự động các sự kiện cũ hơn 90 ngày theo hạn mức lưu trữ F3."""
    cutoff_date = datetime.utcnow() - timedelta(days=90)
    deleted_rows = db.query(DeviceEvent).filter(DeviceEvent.ts < cutoff_date).delete()
    db.commit()
    return {"status": "success", "deleted_records_count": deleted_rows}


@router.delete("/data/purge-child/{child_id}")
def purge_child_data(child_id: int, db: Session = Depends(get_db)):
    """Quyền được quên (Right to be Forgotten): Xóa toàn bộ dữ liệu của một trẻ."""
    del_events = db.query(DeviceEvent).filter(DeviceEvent.child_id == child_id).delete()
    del_policies = db.query(Policy).filter(Policy.child_id == child_id).delete()
    db.commit()
    return {
        "status": "success",
        "message": f"Đã xóa vĩnh viễn toàn bộ dữ liệu liên quan đến trẻ ID {child_id}",
        "events_deleted": del_events,
        "policies_deleted": del_policies,
    }


# ==========================================
# 4. SỐ LIỆU ĐỘNG CHO WEB DASHBOARD
# ==========================================
@router.get("/dashboard-stats/{child_id}")
def get_dashboard_stats(child_id: int, db: Session = Depends(get_db)):
    """Cung cấp dữ liệu động 7 ngày và hôm nay cho giao diện phụ huynh."""
    today_start = datetime.combine(date.today(), datetime.min.time())

    # Tính tổng phút dùng trong ngày hôm nay
    today_events = (
        db.query(DeviceEvent)
        .filter(DeviceEvent.child_id == child_id, DeviceEvent.ts >= today_start)
        .all()
    )
    today_minutes = sum(e.duration_sec for e in today_events) // 60

    # Lấy định mức ngày thường của chính sách
    policy = db.query(Policy).filter(Policy.child_id == child_id).first()
    quota_weekday = policy.daily_quota_weekday_min if policy else 90

    # Lấy biểu đồ 7 ngày gần nhất
    weekly_data = []
    labels = []
    for i in range(6, -1, -1):
        day = date.today() - timedelta(days=i)
        day_start = datetime.combine(day, datetime.min.time())
        day_end = datetime.combine(day, datetime.max.time())

        day_events = (
            db.query(DeviceEvent)
            .filter(
                DeviceEvent.child_id == child_id,
                DeviceEvent.ts >= day_start,
                DeviceEvent.ts <= day_end,
            )
            .all()
        )

        minutes = sum(e.duration_sec for e in day_events) // 60
        weekly_data.append(minutes)
        labels.append(day.strftime("%d/%m"))

    return {
        "today_minutes": today_minutes,
        "quota_minutes": quota_weekday,
        "weekly_labels": labels,
        "weekly_usage": weekly_data,
    }