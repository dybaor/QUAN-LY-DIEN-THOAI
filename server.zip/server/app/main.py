from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.database import engine, Base, SessionLocal
from app.models import Parent, Child
from app.routers import enroll, policy_events, commands

# Tạo bảng SQLite tự động
Base.metadata.create_all(bind=engine)

# Nạp dữ liệu mẫu
db = SessionLocal()
if not db.query(Child).first():
    parent = Parent(username="phuhuynh1", hashed_password="hashed_dummy_password")
    db.add(parent)
    db.commit()
    db.refresh(parent)
    child = Child(name="Bé An", age=10, parent_id=parent.id)
    db.add(child)
    db.commit()
db.close()

app = FastAPI(title="OGK Server - Người Bạn Đồng Hành", version="1.0.0")

# Gắn các Routers
app.include_router(enroll.router)
app.include_router(policy_events.router)
app.include_router(commands.router)

# Thư mục templates ngang hàng với thư mục app
BASE_DIR = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = BASE_DIR / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

@app.get("/", response_class=HTMLResponse)
def serve_dashboard(request: Request):
    return templates.TemplateResponse(
        request=request, 
        name="dashboard.html"
    )