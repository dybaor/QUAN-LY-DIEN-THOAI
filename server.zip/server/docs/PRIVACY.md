﻿# CHÍNH SÁCH BẢO VỆ DỮ LIỆU VÀ QUYỀN RIÊNG TƯ (PRIVACY.MD)
*Tuân thủ Nghị định 13/2023/NĐ-CP về Bảo vệ dữ liệu cá nhân*

---

## 1. BẢNG ĐẶC TẢ DỮ LIỆU THU THẬP (DÀNH CHO PHỤ HUYNH & HỘI ĐỒNG ĐÁNH GIÁ)

| Tên trường dữ liệu | Kiểu dữ liệu | Mục đích thu thập | Thời hạn lưu trữ | Ai được quyền xem? |
| :--- | :--- | :--- | :--- | :--- |
| `ts` | DateTime | Xác định mốc thời gian bắt đầu/kết thúc sự kiện | 90 ngày | Phụ huynh, Trẻ |
| `device_id` | String (UUID) | Định danh máy tính Windows của trẻ | Vĩnh viễn (đến khi gỡ cài đặt) | Hệ thống |
| `child_id` | Integer | Liên kết thiết bị với hồ sơ trẻ | Vĩnh viễn | Phụ huynh |
| `type` | String | Phân loại hoạt động (app_start, locked, v.v.) | 90 ngày | Phụ huynh, Trẻ |
| `subject` | String | Tên app hoặc Domain cấp 2 (Không lưu URL đầy đủ) | 90 ngày | Phụ huynh, Trẻ |
| `duration_sec` | Integer | Tính tổng thời lượng để đối chiếu hạn mức | 90 ngày | Phụ huynh, Trẻ |
| `policy_id` | Integer | Kiểm toán phiên bản chính sách áp dụng | 90 ngày | Phụ huynh |

> **Cam kết bảo mật cốt lõi:** Hệ thống TUYỆT ĐỐI KHÔNG chụp ảnh màn hình, KHÔNG ghi phím gõ (Keylogger), KHÔNG thu thập nội dung tin nhắn hoặc URL đầy đủ (chỉ thu thập tên miền cấp hai như `youtube.com`).

---

## 2. PHIÊN BẢN DÀNH CHO TRẺ EM ĐỌC (NGÔN NGỮ ĐƠN GIẢN)

Chào em, phần mềm **Người Bạn Đồng Hành** hoạt động trên máy tính của em với mục tiêu giúp em cân bằng giữa việc học tập và giải trí:
* **Ứng dụng chỉ ghi lại:** Tên trò chơi/phần mềm em mở và tổng thời gian em ngồi máy tính để nhắc em nghỉ mắt.
* **Ứng dụng KHÔNG bao giờ:** Xem tin nhắn của em, không đọc bài làm của em và không chụp ảnh màn hình của em.
* **Quyền của em:** Em luôn có thể mở mục "Hôm nay em đã dùng gì" để xem toàn bộ thông tin giống như ba mẹ thấy, và có thể bấm nút "Xin thêm giờ" khi cần làm bài tập.