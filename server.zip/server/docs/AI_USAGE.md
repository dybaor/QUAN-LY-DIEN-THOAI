﻿# NHẬT KÝ SỬ DỤNG AI TRONG DỰ ÁN (AI_USAGE.MD)
*Nhóm thực hiện: 03 thành viên*

## 1. Danh sách công cụ AI sử dụng
* Gemini / ChatGPT / Claude: Hỗ trợ phân tích kiến trúc, sinh mã mẫu và giải thích lỗi cú pháp.

## 2. Kê khai các câu Prompt chính và Quá trình tinh chỉnh (Debugging)
* **Prompt 1 (Backend SQLite):** Yêu cầu tạo cấu trúc SQLite tối ưu đa luồng.
  * *Vấn đề phát sinh:* SQLite mặc định bị khóa cơ sở dữ liệu (`database is locked`) khi nhiều tiến trình đọc ghi đồng thời.
  * *Cách nhóm xử lý:* Cấu hình `PRAGMA journal_mode=WAL` để tách biệt luồng ghi và luồng đọc.
* **Prompt 2 (Giao diện Jinja2):** Yêu cầu dựng template Dashboard phụ huynh.
  * *Vấn đề phát sinh:* Lỗi `TypeError: unhashable type: 'dict'` trên Jinja2 v3.1.6.
  * *Cách nhóm xử lý:* Nhóm tìm hiểu tài liệu FastAPI/Starlette và viết lại hàm `TemplateResponse(request=request, name="dashboard.html")`.
* **Prompt 3 (Xử lý lệnh khẩn cấp):** Dùng WebSocket để thay thế HTTP Polling liên tục, giảm thiểu băng thông mạng cục bộ và hạ độ trễ xuống dưới 5 giây.