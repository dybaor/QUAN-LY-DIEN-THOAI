﻿# MÔ HÌNH PHÂN TÍCH ĐE DỌA AN TOÀN HỆ THỐNG (STRIDE)
*Dự án: Hệ thống quản lý thời gian sử dụng thiết bị cho trẻ em (Người Bạn Đồng Hành)*

| Tiêu chuẩn STRIDE | Mối đe dọa tiềm ẩn | Tình huống thực tế của trẻ | Biện pháp kỹ thuật phòng ngừa |
| :--- | :--- | :--- | :--- |
| **S - Spoofing** (Giả mạo) | Thiết bị lạ giả mạo Agent gửi dữ liệu ảo | Giả lập request HTTP gửi về API `/events/batch` | Cơ chế mã ghép đôi 8 ký tự, cấp phát Token gắn liền Fingerprint phần cứng (HWID) |
| **T - Tampering** (Can thiệp/Sửa đổi) | Trẻ chỉnh lùi giờ hệ thống để dùng tiếp | Đổi đồng hồ Windows lùi lại 2 tiếng | Agent đếm giờ bằng `time.monotonic()`, không phụ thuộc vào đồng hồ hệ thống |
| **R - Repudiation** (Chối bỏ trách nhiệm) | Phụ huynh hoặc trẻ chối bỏ các hành động | Phụ huynh quên đã từng cấp quyền mở khóa | Lưu nhật ký kiểm toán (Audit Logs) toàn bộ lệnh khẩn cấp kèm mốc thời gian UTC |
| **I - Information Disclosure** (Lộ lọt thông tin) | Dữ liệu cá nhân của trẻ bị rò rỉ | Xem trộm lịch sử web hoặc tin nhắn của con | Tuân thủ Nghị định 13/2023: chỉ lưu tên miền cấp 2 (không lưu URL), xóa sau 90 ngày |
| **D - Denial of Service** (Từ chối dịch vụ) | Trẻ tìm cách tắt tiến trình quản lý | Mở Task Manager bấm "End Task" | Agent chạy dưới dạng Windows Service quyền LocalSystem (tài khoản thường không tắt được) |
| **E - Elevation of Privilege** (Leo thang đặc quyền) | Trẻ đổi tên file game để qua mặt bộ lọc | Đổi `game.exe` thành `word.exe` | Nhận diện tiến trình bằng bảng băm SHA-256 thay vì dựa vào tên file thực thi |